package np.com.nirajstha.ai_diffusion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
