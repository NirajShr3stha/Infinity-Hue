class Assets {
  static const String bot = 'assets/Logo/bot.png';
}
